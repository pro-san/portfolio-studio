# Portfolio Studio — Full Source

Portfolio Studio is a bilingual Khmer/English portfolio builder built with React + Vite, Node.js + Express, Firebase Authentication, and Cloud Firestore. It includes a responsive dark dashboard, visual section editor (add/edit/hide/delete/reorder), settings, preview, and public portfolio routes.

## Security notice

This source archive does **not** include any service-account private key. The service-account key previously shared in chat should be revoked. Generate a new key only for Firebase project `portfolio-4035c`, store it locally in `server/serviceAccountKey.json`, and never send it in chat, commit it to Git, or put it in the frontend. The Web app config is intentionally left blank in the environment template because the correct values must come from the Web app registered under `portfolio-4035c`.

## Requirements

- Node.js 22+ recommended
- npm
- Firebase project `portfolio-4035c`
- Firebase Authentication with Email/Password enabled
- Cloud Firestore database created
- Web app registered under Project settings → General → Your apps
- New Firebase Admin service-account JSON for the same project

## 1. Configure Firebase

1. Open Firebase Console and select `portfolio-4035c`.
2. Authentication → Sign-in method → enable Email/Password.
3. Firestore Database → create a database. Keep direct client rules restricted; the API uses Firebase Admin.
4. Project settings → General → Your apps → register/select a Web app and copy its config values.
5. Project settings → Service accounts → generate a new private key. Save it locally; never paste it into a chat. Revoke the previously exposed key in Google Cloud IAM → Service Accounts → Keys.

## 2. Configure the frontend

Copy `client/.env.example` to `client/.env` and fill in values from the Web app configuration for **portfolio-4035c**:

```env
VITE_API_URL=http://localhost:4000
VITE_FIREBASE_API_KEY=YOUR_WEB_API_KEY
VITE_FIREBASE_AUTH_DOMAIN=YOUR_AUTH_DOMAIN
VITE_FIREBASE_PROJECT_ID=portfolio-4035c
VITE_FIREBASE_STORAGE_BUCKET=YOUR_STORAGE_BUCKET
VITE_FIREBASE_MESSAGING_SENDER_ID=YOUR_SENDER_ID
VITE_FIREBASE_APP_ID=YOUR_APP_ID
```

Do not reuse values from a different Firebase project. The frontend Web config is not a private key, but should still be configured with appropriate Firebase security settings.

## 3. Configure the backend

Copy `server/.env.example` to `server/.env`:

```env
PORT=4000
CLIENT_ORIGIN=http://localhost:5173
FIREBASE_PROJECT_ID=portfolio-4035c
GOOGLE_APPLICATION_CREDENTIALS=./serviceAccountKey.json
FIREBASE_SERVICE_ACCOUNT_JSON=
```

Place the newly generated JSON file at `server/serviceAccountKey.json`. The backend resolves this relative to the `server` directory even when you start the app from the repository root. The server validates that the key's `project_id` matches `FIREBASE_PROJECT_ID`. For hosted deployment, leave the file off the server image and set `FIREBASE_SERVICE_ACCOUNT_JSON` using the host's protected secret settings instead.

## 4. Install and run locally

From the `portfolio-platform` root folder:

```bash
npm install
cp client/.env.example client/.env
cp server/.env.example server/.env
# Edit both .env files and add the Admin key locally as described above.
npm run dev
```

If you copied the templates after editing them, make sure the required values remain set. The dev command starts both the frontend and backend.

- Frontend: http://localhost:5173
- API health: http://localhost:4000/api/health

Test registration, sign-in, save, publish, and open `/p/your-slug`. A successful health check only confirms the server is running; test an authenticated save to verify Firebase credentials and Firestore access.

## API routes

- `GET /api/health` — public health endpoint
- `GET /api/portfolio/:slug` — fetch a published portfolio
- `GET /api/me/portfolio` — fetch the signed-in user's portfolio (Firebase ID token required)
- `PUT /api/me/portfolio` — save draft (Firebase ID token required)
- `POST /api/me/publish` — publish (Firebase ID token required)

## Netlify frontend

- Base directory: `client`
- Build command: `npm run build`
- Publish directory: `dist`
- Set all `VITE_FIREBASE_*` values from the `portfolio-4035c` Web app and `VITE_API_URL` to the deployed Express API URL.
- Add your Netlify hostname to Firebase Authentication → Settings → Authorized domains.

## Render backend

- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Set `NODE_VERSION=22`, `FIREBASE_PROJECT_ID=portfolio-4035c`, `CLIENT_ORIGIN=https://YOUR-SITE.netlify.app`, and `FIREBASE_SERVICE_ACCOUNT_JSON` as a protected secret containing the new service-account JSON. Do not set the private key as a frontend environment variable.

## Firestore rules

`firestore.rules` denies direct browser reads/writes. The trusted Express API uses Firebase Admin, which bypasses Firestore rules, and verifies Firebase ID tokens before private portfolio routes.

## Scope and limitations

The visual editor operates on structured sections (Hero, About, Skills, Projects, Experience, Contact), rather than arbitrary HTML or script injection. This source includes deploy configuration, but you must supply Firebase project configuration and private credentials. Dependency installation/build should be run in your environment before deployment.
