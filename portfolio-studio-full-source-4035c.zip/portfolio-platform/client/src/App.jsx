import React, { useEffect, useMemo, useState } from 'react'
import {
  onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, updateProfile
} from 'firebase/auth'
import {
  Activity, ArrowDown, ArrowUp, ArrowUpRight, Blocks, BriefcaseBusiness, Check,
  ChevronDown, CircleHelp, Code2, Copy, Eye, EyeOff, FileText, Globe2, GripVertical,
  LayoutDashboard, Link2, LogOut, Mail, Menu, Moon, Palette, Plus, Save, Settings,
  ShieldCheck, Sparkles, Trash2, UserRound, WandSparkles, X, Languages
} from 'lucide-react'
import { auth, firebaseConfigured } from './firebase'

const API = (import.meta.env.VITE_API_URL || 'http://localhost:4000').replace(/\/$/, '')
const translations = {
  en: {
    workspace:'Workspace', overview:'Overview', editor:'Portfolio editor', publicPage:'Public page',
    settings:'Settings', help:'Help center', logout:'Log out', greeting:'Build your next chapter.',
    subtitle:'Design a portfolio that feels like you. Arrange sections, refine your story, and publish when ready.',
    create:'Create portfolio', edit:'Open editor', published:'Published', drafts:'Drafts', views:'Profile views',
    recent:'Your portfolio', quick:'Quick actions', newSection:'Add section', save:'Save changes',
    publish:'Publish site', preview:'Preview', sections:'Page sections', properties:'Section settings',
    canvas:'Live canvas', drag:'Drag sections to reorder', add:'Add a section', title:'Portfolio title',
    slug:'Public URL slug', displayName:'Display name', tagline:'Short tagline', bio:'About you',
    email:'Contact email', skills:'Skills (comma-separated)', projectTitle:'Project title',
    projectDescription:'Project description', sectionTitle:'Section title', text:'Content',
    signIn:'Sign in', signUp:'Create account', welcome:'Welcome to Portfolio Studio',
    authHint:'Sign in to build and publish your portfolio.', emailAddress:'Email address',
    password:'Password', fullName:'Full name', noAccount:'New here?', hasAccount:'Already have an account?',
    config:'Firebase setup required', configHint:'Add your Firebase web configuration to client/.env to enable account sign-in.',
    saveSuccess:'Portfolio saved', publishSuccess:'Your public portfolio is live!', addHint:'Choose a section to add to your page.',
    hero:'Hero', about:'About', skillSection:'Skills', projects:'Projects', experience:'Experience', contact:'Contact',
    visible:'Visible', hidden:'Hidden', moveUp:'Move up', moveDown:'Move down', remove:'Remove section',
    language:'Language', darkMode:'Dark studio', status:'Status', draft:'Draft', live:'Live',
    publicLink:'Open public portfolio', copyLink:'Copy link', signInError:'Could not sign in. Check your details and Firebase setup.',
    nameRequired:'Please enter your name.', empty:'No sections yet. Add your first section to start building.',
    savedAt:'Autosave is not enabled. Save changes to store your latest edits.',
  },
  km: {
    workspace:'កន្លែងធ្វើការ', overview:'ទិដ្ឋភាពទូទៅ', editor:'កែសម្រួល Portfolio', publicPage:'ទំព័រសាធារណៈ',
    settings:'ការកំណត់', help:'ជំនួយ', logout:'ចាកចេញ', greeting:'បង្កើតជំពូកថ្មីរបស់អ្នក។',
    subtitle:'រចនា Portfolio តាមរចនាប័ទ្មរបស់អ្នក។ រៀបចំផ្នែក កែសម្រួលរឿងរ៉ាវ និងផ្សព្វផ្សាយនៅពេលរួចរាល់។',
    create:'បង្កើត Portfolio', edit:'បើកកម្មវិធីកែសម្រួល', published:'បានផ្សព្វផ្សាយ', drafts:'សេចក្តីព្រាង', views:'ចំនួនមើល',
    recent:'Portfolio របស់អ្នក', quick:'សកម្មភាពរហ័ស', newSection:'បន្ថែមផ្នែក', save:'រក្សាទុកការកែប្រែ',
    publish:'ផ្សព្វផ្សាយគេហទំព័រ', preview:'មើលជាមុន', sections:'ផ្នែកទំព័រ', properties:'ការកំណត់ផ្នែក',
    canvas:'ផ្ទាំងបង្ហាញផ្ទាល់', drag:'អូសផ្នែកដើម្បីរៀបលំដាប់', add:'បន្ថែមផ្នែក', title:'ចំណងជើង Portfolio',
    slug:'ឈ្មោះតំណសាធារណៈ', displayName:'ឈ្មោះបង្ហាញ', tagline:'ពាក្យពិពណ៌នាខ្លី', bio:'អំពីអ្នក',
    email:'អ៊ីមែលទំនាក់ទំនង', skills:'ជំនាញ (បំបែកដោយក្បៀស)', projectTitle:'ចំណងជើងគម្រោង',
    projectDescription:'ការពិពណ៌នាគម្រោង', sectionTitle:'ចំណងជើងផ្នែក', text:'ខ្លឹមសារ',
    signIn:'ចូលគណនី', signUp:'បង្កើតគណនី', welcome:'សូមស្វាគមន៍មកកាន់ Portfolio Studio',
    authHint:'ចូលគណនីដើម្បីបង្កើត និងផ្សព្វផ្សាយ Portfolio របស់អ្នក។', emailAddress:'អាសយដ្ឋានអ៊ីមែល',
    password:'ពាក្យសម្ងាត់', fullName:'ឈ្មោះពេញ', noAccount:'មិនទាន់មានគណនី?', hasAccount:'មានគណនីរួចហើយ?',
    config:'ត្រូវការកំណត់ Firebase', configHint:'បញ្ចូលការកំណត់ Firebase Web ក្នុង client/.env ដើម្បីបើកការចូលគណនី។',
    saveSuccess:'បានរក្សាទុក Portfolio', publishSuccess:'Portfolio សាធារណៈរបស់អ្នកបានផ្សព្វផ្សាយហើយ!', addHint:'ជ្រើសរើសផ្នែកដើម្បីបន្ថែមទៅទំព័រ។',
    hero:'ផ្នែកដើម', about:'អំពីខ្ញុំ', skillSection:'ជំនាញ', projects:'គម្រោង', experience:'បទពិសោធន៍', contact:'ទំនាក់ទំនង',
    visible:'បង្ហាញ', hidden:'លាក់', moveUp:'ផ្លាស់ទីឡើង', moveDown:'ផ្លាស់ទីចុះ', remove:'លុបផ្នែក',
    language:'ភាសា', darkMode:'រចនាប័ទ្មងងឹត', status:'ស្ថានភាព', draft:'សេចក្តីព្រាង', live:'ផ្សាយផ្ទាល់',
    publicLink:'បើក Portfolio សាធារណៈ', copyLink:'ចម្លងតំណ', signInError:'មិនអាចចូលបានទេ។ សូមពិនិត្យព័ត៌មាន និង Firebase។',
    nameRequired:'សូមបញ្ចូលឈ្មោះរបស់អ្នក។', empty:'មិនទាន់មានផ្នែកទេ។ បន្ថែមផ្នែកដំបូងដើម្បីចាប់ផ្តើម។',
    savedAt:'មិនបានបើករក្សាទុកស្វ័យប្រវត្តិទេ។ សូមចុចរក្សាទុក។',
  }
}
const SECTION_TYPES = ['hero','about','skills','projects','experience','contact']
const makeSection = (type) => ({
  id: crypto.randomUUID(), type, visible: true,
  title: ({hero:'Hello, I’m',about:'A little about me',skills:'What I work with',projects:'Selected work',experience:'Experience',contact:'Let’s connect'})[type],
  content: ({hero:'Designer & developer creating thoughtful digital experiences.',about:'I enjoy turning complex problems into simple, beautiful, and intuitive experiences.',skills:'React, JavaScript, UI/UX, Node.js, Firebase',projects:'Portfolio Website — A responsive personal website built with React.\nTask Flow — A clean productivity dashboard.',experience:'Product Designer · 2022 — Present\nFreelance Developer · 2020 — 2022',contact:'Have a project in mind? I would love to hear from you.'})[type],
})
const initialPortfolio = () => ({
  title:'My Portfolio', slug:'my-portfolio', displayName:'Alex Morgan',
  tagline:'Digital designer & developer', email:'hello@example.com', bio:'I create digital experiences that are useful, thoughtful, and a little unexpected.',
  published:false, sections:[makeSection('hero'),makeSection('about'),makeSection('skills'),makeSection('projects'),makeSection('contact')]
})
function slugify(s) { return (s || 'my-portfolio').toLowerCase().trim().replace(/[^a-z0-9-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,48) || 'my-portfolio' }

function AuthScreen({ lang, setLang, t }) {
  const [mode,setMode] = useState('signin')
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [name,setName] = useState('')
  const [error,setError] = useState('')
  const [busy,setBusy] = useState(false)
  async function submit(e) {
    e.preventDefault(); setError('')
    if (!auth) return
    if (mode === 'signup' && !name.trim()) { setError(t.nameRequired); return }
    setBusy(true)
    try {
      if (mode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth,email,password)
        await updateProfile(cred.user,{displayName:name.trim()})
      } else await signInWithEmailAndPassword(auth,email,password)
    } catch (err) { setError(err.code === 'auth/operation-not-allowed' ? 'Enable Email/Password in Firebase Authentication.' : (err.message || t.signInError)) }
    finally { setBusy(false) }
  }
  return <div className="auth-page">
    <div className="auth-glow glow-one"/><div className="auth-glow glow-two"/>
    <header className="auth-top"><Brand/><button className="lang-button" onClick={()=>setLang(lang==='en'?'km':'en')}><Languages size={16}/>{lang==='en'?'ខ្មែរ':'English'}</button></header>
    <div className="auth-content">
      <div className="auth-copy"><div className="eyebrow"><Sparkles size={15}/> PORTFOLIO STUDIO</div><h1>{t.welcome}</h1><p>{t.authHint}</p><div className="auth-points"><span><Check size={16}/> Visual drag-and-drop builder</span><span><Check size={16}/> Publish a shareable profile</span><span><Check size={16}/> English & Khmer interface</span></div></div>
      <form className="auth-card" onSubmit={submit}>
        <div className="auth-card-head"><div className="avatar-mark"><UserRound/></div><div><h2>{mode==='signin'?t.signIn:t.signUp}</h2><p>{mode==='signin'?'Continue to your workspace':'Start building your online presence'}</p></div></div>
        {!firebaseConfigured && <div className="notice"><CircleHelp size={17}/><div><b>{t.config}</b><p>{t.configHint}</p></div></div>}
        {mode==='signup'&&<label>{t.fullName}<input value={name} onChange={e=>setName(e.target.value)} placeholder="Alex Morgan" autoComplete="name"/></label>}
        <label>{t.emailAddress}<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email"/></label>
        <label>{t.password}<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" required minLength={6} autoComplete={mode==='signin'?'current-password':'new-password'}/></label>
        {error&&<div className="error-text">{error}</div>}
        <button className="primary-button full-button" disabled={busy||!firebaseConfigured}>{busy?'Please wait…':mode==='signin'?t.signIn:t.signUp}<ArrowUpRight size={17}/></button>
        <p className="auth-switch">{mode==='signin'?t.noAccount:t.hasAccount} <button type="button" onClick={()=>{setMode(mode==='signin'?'signup':'signin');setError('')}}>{mode==='signin'?t.signUp:t.signIn}</button></p>
        <div className="secure-note"><ShieldCheck size={14}/> Secure sign-in powered by Firebase</div>
      </form>
    </div>
    <footer className="auth-footer"><span>© 2026 Portfolio Studio</span><span>Make your work visible.</span></footer>
  </div>
}
function Brand() { return <div className="brand"><div className="brand-icon"><Blocks size={19}/></div><span>folio<span className="brand-dot">.</span>studio</span></div> }

function SectionContent({ section, portfolio, t, compact=false }) {
  if (section.type==='hero') return <div className="hero-content"><div className="hero-badge"><span className="status-dot"/> AVAILABLE FOR OPPORTUNITIES</div><h1>{portfolio.displayName || 'Your Name'}<br/><span>{portfolio.tagline || 'Your next big idea starts here.'}</span></h1><p>{section.content}</p><div className="hero-actions"><span className="preview-cta">{t.contact} <ArrowUpRight size={15}/></span><span className="text-link">Explore my work <ArrowDown size={14}/></span></div></div>
  if (section.type==='about') return <div className="preview-section"><div className="preview-kicker">01 / ABOUT</div><h2>{section.title}</h2><p>{section.content}</p></div>
  if (section.type==='skills') return <div className="preview-section"><div className="preview-kicker">02 / TOOLKIT</div><h2>{section.title}</h2><div className="skill-chips">{section.content.split(',').map(x=>x.trim()).filter(Boolean).map(x=><span key={x}>{x}</span>)}</div></div>
  if (section.type==='projects') return <div className="preview-section"><div className="preview-kicker">03 / SELECTED WORK</div><h2>{section.title}</h2><div className="preview-projects">{section.content.split('\n').filter(Boolean).map((line,i)=>{const [name,...rest]=line.split(' — ');return <div className="preview-project" key={i}><div className="project-visual"><Code2 size={25}/><span>0{i+1}</span></div><h3>{name}</h3><p>{rest.join(' — ')||'A selected project from my portfolio.'}</p></div>})}</div></div>
  if (section.type==='experience') return <div className="preview-section"><div className="preview-kicker">04 / EXPERIENCE</div><h2>{section.title}</h2><div className="experience-lines">{section.content.split('\n').filter(Boolean).map((x,i)=><div key={i}><span className="timeline-dot"/><p>{x}</p></div>)}</div></div>
  return <div className="preview-section contact-preview"><div className="preview-kicker">05 / CONTACT</div><h2>{section.title}</h2><p>{section.content}</p><span className="contact-email"><Mail size={15}/>{portfolio.email || 'hello@example.com'}</span></div>
}
function Preview({ portfolio, t, compact=false }) {
  const sections = portfolio.sections.filter(s=>s.visible)
  return <div className={`portfolio-preview ${compact?'compact-preview':''}`}>
    <div className="preview-nav"><div className="preview-logo">{(portfolio.displayName||'A').split(' ').map(x=>x[0]).join('').slice(0,2)}<span>.</span></div><div className="preview-nav-links"><span>Work</span><span>About</span><span>Contact ↗</span></div></div>
    {sections.length===0&&<div className="empty-preview">{t.empty}</div>}
    {sections.map(s=><section key={s.id} className={`preview-block ${s.type==='hero'?'preview-hero':''}`}><SectionContent section={s} portfolio={portfolio} t={t} compact={compact}/></section>)}
    <footer className="preview-footer"><span>© {new Date().getFullYear()} {portfolio.displayName}</span><span>Made with folio.studio ✦</span></footer>
  </div>
}

function Dashboard({ user, lang, setLang, t, onLogout }) {
  const [page,setPage] = useState('overview')
  const [portfolio,setPortfolio] = useState(initialPortfolio)
  const [selected,setSelected] = useState('')
  const [busy,setBusy] = useState(false)
  const [notice,setNotice] = useState('')
  const [mobileNav,setMobileNav] = useState(false)
  const [dragging,setDragging] = useState(null)
  const [dropIndex,setDropIndex] = useState(null)
  const [tab,setTab] = useState('edit')
  const [saved,setSaved] = useState(false)
  const [showAdd,setShowAdd] = useState(false)
  const [slugInput,setSlugInput] = useState('')
  const [publishedUrl,setPublishedUrl] = useState('')
  const token = async () => await user.getIdToken()
  useEffect(()=>{
    let alive=true
    ;(async()=>{try{const r=await fetch(`${API}/api/me/portfolio`,{headers:{Authorization:`Bearer ${await token()}`}});if(r.ok){const data=await r.json();if(alive&&data.portfolio){setPortfolio(p=>({...p,...data.portfolio,sections:Array.isArray(data.portfolio.sections)?data.portfolio.sections:p.sections}));setSlugInput(data.portfolio.slug||'')}}}catch{}})()
    return ()=>{alive=false}
  },[user.uid])
  useEffect(()=>{if(!selected&&portfolio.sections[0])setSelected(portfolio.sections[0].id)},[portfolio.sections,selected])
  const currentSection=portfolio.sections.find(s=>s.id===selected)
  const updatePortfolio=(key,value)=>{setPortfolio(p=>({...p,[key]:value}));setSaved(false)}
  const updateSection=(key,value)=>{setPortfolio(p=>({...p,sections:p.sections.map(s=>s.id===selected?{...s,[key]:value}:s)}));setSaved(false)}
  const addSection=(type)=>{const s=makeSection(type);setPortfolio(p=>({...p,sections:[...p.sections,s]}));setSelected(s.id);setShowAdd(false);setPage('editor');setSaved(false)}
  const removeSection=(id)=>{setPortfolio(p=>({...p,sections:p.sections.filter(s=>s.id!==id)}));if(selected===id)setSelected('');setSaved(false)}
  const reorder=(from,to)=>{if(from===null||to===null||from===to)return;setPortfolio(p=>{const arr=[...p.sections];const [item]=arr.splice(from,1);arr.splice(to,0,item);return {...p,sections:arr}});setSaved(false)}
  async function save(publish=false) {
    setBusy(true);setNotice('')
    const next={...portfolio,slug:slugify(slugInput||portfolio.slug),published:publish?true:portfolio.published}
    try {
      const r=await fetch(`${API}${publish?'/api/me/publish':'/api/me/portfolio'}`,{method:publish?'POST':'PUT',headers:{'Content-Type':'application/json',Authorization:`Bearer ${await token()}`},body:JSON.stringify(next)})
      const data=await r.json()
      if(!r.ok)throw new Error(data.error||'Could not save portfolio')
      setPortfolio(next);setSlugInput(next.slug);setSaved(true)
      const url=`${window.location.origin}/p/${next.slug}`;setPublishedUrl(url)
      setNotice(publish?t.publishSuccess:t.saveSuccess)
    } catch(err) {setNotice(`${err.message}. Check that the API server is running and configured.`)}
    finally {setBusy(false)}
  }
  async function copyLink(){const url=publishedUrl||`${window.location.origin}/p/${slugify(slugInput||portfolio.slug)}`;try{await navigator.clipboard.writeText(url);setNotice(t.copyLink+' ✓')}catch{setNotice(url)}}
  const navItems=[['overview',LayoutDashboard,t.overview],['editor',Palette,t.editor],['public',Globe2,t.publicPage],['settings',Settings,t.settings]]
  const sectionLabel=(type)=>({hero:t.hero,about:t.about,skills:t.skillSection,projects:t.projects,experience:t.experience,contact:t.contact})[type]||type
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'mobile-open':''}`}>
      <div className="sidebar-brand"><Brand/><button className="icon-button sidebar-close" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace-label">{t.workspace}<ChevronDown size={14}/></div>
      <div className="workspace-card"><div className="workspace-avatar"><Blocks size={18}/></div><div><b>Personal workspace</b><small>Free plan</small></div><span className="online-dot"/></div>
      <div className="nav-caption">MENU</div>
      <nav className="side-nav">{navItems.map(([id,Icon,label])=><button key={id} className={page===id?'active':''} onClick={()=>{setPage(id);setMobileNav(false)}}><Icon size={18}/><span>{label}</span>{id==='editor'&&<span className="nav-shortcut">⌘ E</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="upgrade-card"><div className="upgrade-icon"><Sparkles size={17}/></div><b>Make it yours</b><p>Your story deserves a great home on the web.</p><button onClick={()=>setPage('editor')}>Customize portfolio <ArrowUpRight size={14}/></button></div><div className="user-mini"><div className="user-avatar">{(user.displayName||user.email||'U')[0].toUpperCase()}</div><div className="user-mini-info"><b>{user.displayName||'Portfolio user'}</b><small>{user.email}</small></div><button className="icon-button" title={t.logout} onClick={onLogout}><LogOut size={17}/></button></div></div>
    </aside>
    {mobileNav&&<button className="mobile-scrim" onClick={()=>setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="icon-button mobile-menu" onClick={()=>setMobileNav(true)}><Menu size={20}/></button><span className="breadcrumb">Workspace <span>/</span> <b>{navItems.find(x=>x[0]===page)?.[2]||t.overview}</b></span></div><div className="topbar-actions"><span className="topbar-status"><span className="status-dot"/> All systems normal</span><button className="lang-button" onClick={()=>setLang(lang==='en'?'km':'en')}><Languages size={15}/>{lang==='en'?'ខ្មែរ':'English'}</button><button className="icon-button" title="Help"><CircleHelp size={18}/></button><div className="top-avatar">{(user.displayName||user.email||'U')[0].toUpperCase()}</div></div></header>
      <div className="page-content">
        {notice&&<div className={`toast ${notice.includes('Check that')||notice.includes('Could not')?'toast-error':''}`}><Check size={16}/><span>{notice}</span><button onClick={()=>setNotice('')}><X size={15}/></button></div>}
        {page==='overview'&&<div className="overview-page">
          <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR CREATIVE SPACE</div><h1>{t.greeting}</h1><p>{t.subtitle}</p></div><button className="primary-button" onClick={()=>setPage('editor')}><WandSparkles size={17}/>{t.create}<ArrowUpRight size={16}/></button></div>
          <div className="stats-grid"><Stat icon={Globe2} label={t.published} value={portfolio.published?'1':'0'} foot={portfolio.published?'Your site is live':'Ready when you are'} tone="violet"/><Stat icon={FileText} label={t.drafts} value={portfolio.published?'0':'1'} foot="Portfolio workspace" tone="blue"/><Stat icon={Activity} label={t.views} value="—" foot="Analytics coming soon" tone="green"/></div>
          <div className="overview-grid"><div className="panel portfolio-panel"><div className="panel-head"><div><h3>{t.recent}</h3><p>Your latest creative work</p></div><button className="text-button" onClick={()=>setPage('editor')}>{t.edit}<ArrowUpRight size={15}/></button></div><div className="portfolio-list-row"><div className="portfolio-thumb"><div className="thumb-orbit"/><span>{(portfolio.displayName||'A').slice(0,1)}</span></div><div className="portfolio-list-info"><b>{portfolio.title||'Untitled portfolio'}</b><span><Globe2 size={13}/>{portfolio.slug||'your-portfolio'}</span><small>Edited just now</small></div><span className={`pill ${portfolio.published?'pill-live':'pill-draft'}`}><span/>{portfolio.published?t.live:t.draft}</span><button className="icon-button" onClick={()=>setPage('editor')}><ArrowUpRight size={17}/></button></div><div className="portfolio-list-foot"><span><Blocks size={14}/>{portfolio.sections.length} sections</span><span><ShieldCheck size={14}/> Private until published</span></div></div><div className="panel quick-panel"><div className="panel-head"><div><h3>{t.quick}</h3><p>Jump back in</p></div></div><button className="quick-action" onClick={()=>setPage('editor')}><div className="quick-icon violet"><Palette size={18}/></div><span><b>Edit your design</b><small>Customize sections and content</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setPage('settings')}><div className="quick-icon blue"><Settings size={18}/></div><span><b>Portfolio settings</b><small>Update your public profile</small></span><ArrowUpRight size={16}/></button><button className="quick-action" onClick={()=>setPage('public')}><div className="quick-icon green"><Eye size={18}/></div><span><b>Preview your page</b><small>See your portfolio as visitors do</small></span><ArrowUpRight size={16}/></button></div></div>
          <div className="bottom-tip"><div className="tip-icon"><Sparkles size={19}/></div><div><b>A little tip to get you started</b><p>Keep your introduction short, show your best work first, and add a clear way for people to contact you.</p></div><button className="icon-button" onClick={()=>setPage('editor')}><ArrowUpRight size={18}/></button></div>
        </div>}
        {page==='editor'&&<div className="editor-page">
          <div className="editor-heading"><div><div className="eyebrow"><Palette size={14}/> DESIGN WORKSPACE</div><h1>{t.editor}</h1><p>Shape your story, one section at a time.</p></div><div className="editor-heading-actions"><button className="secondary-button" onClick={()=>setTab(tab==='edit'?'preview':'edit')}><Eye size={16}/>{tab==='edit'?t.preview:'Edit'}</button><button className="primary-button" disabled={busy} onClick={()=>save(false)}><Save size={16}/>{busy?'Saving…':t.save}</button></div></div>
          <div className="editor-toolbar"><div className="toolbar-tabs"><button className={tab==='edit'?'selected':''} onClick={()=>setTab('edit')}><Blocks size={15}/>Editor</button><button className={tab==='preview'?'selected':''} onClick={()=>setTab('preview')}><Eye size={15}/>{t.preview}</button></div><span className="editor-hint"><GripVertical size={14}/>{t.drag}</span><button className="add-section-button" onClick={()=>setShowAdd(!showAdd)}><Plus size={16}/>{t.add}</button></div>
          {showAdd&&<div className="add-section-popover"><div className="add-popover-head"><b>{t.add}</b><button className="icon-button" onClick={()=>setShowAdd(false)}><X size={16}/></button></div><p>{t.addHint}</p><div className="add-types">{SECTION_TYPES.map((type,i)=><button key={type} onClick={()=>addSection(type)}><span>{['Aa','¶','◈','▧','↗','✉'][i]}</span>{sectionLabel(type)}<Plus size={14}/></button>)}</div></div>}
          {tab==='preview'?<div className="full-preview-wrap"><div className="preview-browser"><div className="browser-dots"><i/><i/><i/></div><span><ShieldCheck size={13}/>{portfolio.slug||'your-portfolio'}.folio.studio</span><button onClick={()=>setTab('edit')}><X size={14}/></button></div><Preview portfolio={portfolio} t={t}/></div>:
          <div className="editor-layout">
            <div className="sections-panel panel"><div className="panel-head"><div><h3>{t.sections}</h3><p>{portfolio.sections.length} blocks on your page</p></div><button className="icon-button" onClick={()=>setShowAdd(!showAdd)}><Plus size={17}/></button></div>
              <div className="section-list">{portfolio.sections.map((s,i)=><div key={s.id} draggable onDragStart={()=>setDragging(i)} onDragOver={e=>{e.preventDefault();setDropIndex(i)}} onDrop={e=>{e.preventDefault();reorder(dragging,i);setDragging(null);setDropIndex(null)}} onDragEnd={()=>{setDragging(null);setDropIndex(null)}} className={`section-row ${selected===s.id?'selected':''} ${dropIndex===i?'drop-target':''}`} onClick={()=>setSelected(s.id)}><span className="drag-handle"><GripVertical size={16}/></span><div className="section-type-icon">{['Aa','¶','◈','▧','↗','✉'][SECTION_TYPES.indexOf(s.type)]}</div><div className="section-row-info"><b>{sectionLabel(s.type)}</b><small>{s.title}</small></div><button className={`visibility-button ${s.visible?'':'muted'}`} title={s.visible?t.visible:t.hidden} onClick={e=>{e.stopPropagation();setPortfolio(p=>({...p,sections:p.sections.map(x=>x.id===s.id?{...x,visible:!x.visible}:x)}));setSaved(false)}}>{s.visible?<Eye size={15}/>:<EyeOff size={15}/>}</button></div>)}</div>
              <button className="add-section-wide" onClick={()=>setShowAdd(!showAdd)}><Plus size={16}/>{t.newSection}</button>
              <div className="section-help"><CircleHelp size={16}/><span>Drag blocks to change the order. Select a block to edit its content.</span></div>
            </div>
            <div className="canvas-panel"><div className="canvas-title"><div><span className="live-dot"/><b>{t.canvas}</b><small>Desktop · 100%</small></div><span className="canvas-tag">LIVE PREVIEW</span></div><div className="canvas-viewport"><Preview portfolio={portfolio} t={t} compact/></div></div>
            <div className="properties-panel panel"><div className="panel-head"><div><h3>{t.properties}</h3><p>{currentSection?sectionLabel(currentSection.type):'Page content'}</p></div><Settings size={17}/></div>
              {currentSection?<div className="property-form"><label>{t.sectionTitle}<input value={currentSection.title} onChange={e=>updateSection('title',e.target.value)}/></label><label>{t.text}<textarea rows={currentSection.type==='hero'?5:7} value={currentSection.content} onChange={e=>updateSection('content',e.target.value)} placeholder="Write something about this section…"/></label>{currentSection.type==='skills'&&<p className="field-hint">Separate each skill with a comma.</p>}<div className="property-toggle"><span><b>{t.visible}</b><small>Show this section on your page</small></span><button className={`toggle ${currentSection.visible?'on':''}`} onClick={()=>updateSection('visible',!currentSection.visible)}><span/></button></div><button className="danger-button" onClick={()=>removeSection(currentSection.id)}><Trash2 size={15}/>{t.remove}</button></div>:<div className="property-empty"><Settings size={25}/><p>Select a section from the left to edit its content.</p></div>}
            </div>
          </div>}
        </div>}
        {page==='public'&&<div className="public-page"><div className="editor-heading"><div><div className="eyebrow"><Globe2 size={14}/> PUBLISHING</div><h1>{t.publicPage}</h1><p>See how your work appears to the world.</p></div><button className="primary-button" onClick={()=>save(true)} disabled={busy}><Globe2 size={16}/>{busy?'Publishing…':t.publish}</button></div><div className="publish-card panel"><div className="publish-card-icon"><Globe2 size={22}/></div><div className="publish-card-content"><h3>{portfolio.published?'Your portfolio is published':'Your portfolio is not public yet'}</h3><p>{portfolio.published?'Your page is ready to share with the world.':'Publish your portfolio to create a public page that anyone can visit.'}</p><div className="slug-field"><span>folio.studio/p/</span><input value={slugInput||portfolio.slug} onChange={e=>{setSlugInput(slugify(e.target.value));setSaved(false)}} placeholder="your-name"/></div><div className="publish-actions"><button className="secondary-button" onClick={()=>setPage('editor')}><Palette size={15}/>Edit portfolio</button><button className="secondary-button" onClick={copyLink}><Copy size={15}/>{t.copyLink}</button>{portfolio.published&&<a className="primary-button link-button" href={`/p/${portfolio.slug}`} target="_blank" rel="noreferrer"><Eye size={15}/>{t.publicLink}</a>}</div></div><span className={`pill ${portfolio.published?'pill-live':'pill-draft'}`}><span/>{portfolio.published?t.live:t.draft}</span></div><div className="public-preview"><div className="preview-label">PAGE PREVIEW</div><Preview portfolio={portfolio} t={t}/></div></div>}
        {page==='settings'&&<div className="settings-page"><div className="editor-heading"><div><div className="eyebrow"><Settings size={14}/> PREFERENCES</div><h1>{t.settings}</h1><p>Manage your profile and public portfolio details.</p></div><button className="primary-button" onClick={()=>save(false)} disabled={busy}><Save size={16}/>{t.save}</button></div><div className="settings-grid"><div className="panel settings-card"><div className="settings-card-head"><div className="settings-card-icon"><UserRound size={18}/></div><div><h3>Profile information</h3><p>Details visitors see on your portfolio</p></div></div><div className="settings-form"><label>{t.title}<input value={portfolio.title} onChange={e=>updatePortfolio('title',e.target.value)}/></label><label>{t.displayName}<input value={portfolio.displayName} onChange={e=>updatePortfolio('displayName',e.target.value)}/></label><label>{t.tagline}<input value={portfolio.tagline} onChange={e=>updatePortfolio('tagline',e.target.value)}/></label><label>{t.bio}<textarea rows={4} value={portfolio.bio} onChange={e=>updatePortfolio('bio',e.target.value)}/></label><label>{t.email}<input type="email" value={portfolio.email} onChange={e=>updatePortfolio('email',e.target.value)}/></label></div></div><div className="panel settings-card"><div className="settings-card-head"><div className="settings-card-icon blue"><Link2 size={18}/></div><div><h3>Public URL</h3><p>Choose a memorable portfolio link</p></div></div><div className="settings-form"><label>{t.slug}<div className="input-prefix"><span>/p/</span><input value={slugInput||portfolio.slug} onChange={e=>{setSlugInput(slugify(e.target.value));setSaved(false)}}/></div></label><div className="url-preview"><Globe2 size={17}/><span>{window.location.origin}/p/{slugify(slugInput||portfolio.slug)}</span></div><p className="field-hint">Use lowercase letters, numbers, and hyphens.</p><div className="setting-info"><ShieldCheck size={17}/><span>Your page stays private until you publish it. Anyone with a published link can view it.</span></div><button className="secondary-button" onClick={()=>setPage('public')}><Eye size={15}/>Publishing settings</button></div></div></div></div>}
      </div>
    </main>
  </div>
}
function Stat({icon:Icon,label,value,foot,tone}){return <div className="stat-card panel"><div className={`stat-icon ${tone}`}><Icon size={19}/></div><span className="stat-label">{label}</span><div className="stat-value">{value}</div><div className="stat-foot"><span className="stat-foot-dot"/>{foot}</div></div>}

function PublicPortfolio({ slug, lang, setLang, t }) {
  const [portfolio,setPortfolio]=useState(null)
  const [error,setError]=useState(false)
  useEffect(()=>{fetch(`${API}/api/portfolio/${encodeURIComponent(slug)}`).then(r=>r.ok?r.json():Promise.reject()).then(d=>setPortfolio(d.portfolio)).catch(()=>setError(true))},[slug])
  return <div className="public-route"><header className="public-route-bar"><Brand/><button className="lang-button" onClick={()=>setLang(lang==='en'?'km':'en')}><Languages size={15}/>{lang==='en'?'ខ្មែរ':'English'}</button></header>{portfolio?<div className="public-route-content"><Preview portfolio={portfolio} t={t}/></div>:<div className="public-not-found"><div className="avatar-mark"><Globe2/></div><h1>{error?'Portfolio not found':'Loading portfolio…'}</h1><p>{error?'This portfolio may be unpublished or the link may be incorrect.':'Getting the portfolio ready.'}</p><a href="/" className="primary-button link-button">Create your own portfolio <ArrowUpRight size={16}/></a></div>}</div>
}
export default function App(){
  const [lang,setLang]=useState('en')
  const [user,setUser]=useState(undefined)
  const [route,setRoute]=useState({type:'app'})
  const t=translations[lang]
  useEffect(()=>{const handle=()=>{const match=window.location.pathname.match(/^\/p\/([^/]+)/);setRoute(match?{type:'public',slug:decodeURIComponent(match[1])}:{type:'app'})};handle();window.addEventListener('popstate',handle);return()=>window.removeEventListener('popstate',handle)},[])
  useEffect(()=>{if(!auth){setUser(null);return}return onAuthStateChanged(auth,u=>setUser(u))},[])
  if(route.type==='public')return <PublicPortfolio slug={route.slug} lang={lang} setLang={setLang} t={t}/>
  if(user===undefined)return <div className="loading-screen"><div className="loading-mark"><Blocks/></div><div className="loading-line"/></div>
  if(!user)return <AuthScreen lang={lang} setLang={setLang} t={t}/>
  return <Dashboard user={user} lang={lang} setLang={setLang} t={t} onLogout={()=>signOut(auth)}/>
}