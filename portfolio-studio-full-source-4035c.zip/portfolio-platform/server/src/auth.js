import { authAdmin } from './firebaseAdmin.js'

export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || ''
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing Firebase ID token.' })
  try {
    req.user = await authAdmin.verifyIdToken(header.slice(7))
    return next()
  } catch {
    return res.status(401).json({ error: 'Invalid or expired authentication token.' })
  }
}