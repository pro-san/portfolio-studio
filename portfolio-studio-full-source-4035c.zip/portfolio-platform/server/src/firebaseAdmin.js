import 'dotenv/config'
import admin from 'firebase-admin'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const serverDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

function readServiceAccount() {
  const inline = process.env.FIREBASE_SERVICE_ACCOUNT_JSON?.trim()
  if (inline) {
    try { return JSON.parse(inline) }
    catch { throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is not valid JSON. Use the complete service-account JSON as a secret value.') }
  }

  const configuredPath = process.env.GOOGLE_APPLICATION_CREDENTIALS?.trim() || './serviceAccountKey.json'
  const keyPath = path.isAbsolute(configuredPath) ? configuredPath : path.resolve(serverDir, configuredPath)
  if (!fs.existsSync(keyPath)) {
    throw new Error(`Firebase Admin credentials not found at ${keyPath}. Generate a private key for project ${process.env.FIREBASE_PROJECT_ID || 'configured project'} and save it there, or set FIREBASE_SERVICE_ACCOUNT_JSON in the backend environment.`)
  }
  try { return JSON.parse(fs.readFileSync(keyPath, 'utf8')) }
  catch (err) {
    if (err instanceof SyntaxError) throw new Error(`Firebase Admin credential file is not valid JSON: ${keyPath}`)
    throw err
  }
}

function initializeFirebaseAdmin() {
  if (admin.apps.length) return admin
  const projectId = (process.env.FIREBASE_PROJECT_ID || '').trim()
  if (!projectId) throw new Error('FIREBASE_PROJECT_ID is required in server/.env.')

  const serviceAccount = readServiceAccount()
  if (!serviceAccount.project_id || serviceAccount.project_id !== projectId) {
    throw new Error(`Firebase project mismatch: server/.env uses ${projectId}, but the service-account key belongs to ${serviceAccount.project_id || 'an unknown project'}. Generate credentials from the selected Firebase project.`)
  }
  if (!serviceAccount.client_email || !serviceAccount.private_key) {
    throw new Error('Firebase Admin service-account JSON is missing client_email or private_key.')
  }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount), projectId })
  console.log(`Firebase Admin connected to project ${projectId}`)
  return admin
}

export const firebaseAdmin = initializeFirebaseAdmin()
export const db = firebaseAdmin.firestore()
export const authAdmin = firebaseAdmin.auth()
