import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { db } from './firebaseAdmin.js'
import { requireAuth } from './auth.js'

const app = express()
app.disable('x-powered-by')
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }))
const origins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map(s => s.trim()).filter(Boolean)
app.use(cors({ origin(origin, callback) {
  if (!origin || origins.includes('*') || origins.includes(origin)) return callback(null, true)
  return callback(new Error('Origin not allowed by CORS'))
} }))
app.use(express.json({ limit: '1mb' }))

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'portfolio-api', time: new Date().toISOString() }))
app.get('/api/portfolio/:slug', async (req, res, next) => {
  try {
    const snap = await db.collection('portfolios').where('slug', '==', req.params.slug).limit(1).get()
    if (snap.empty || snap.docs[0].data().published !== true) return res.status(404).json({ error: 'Portfolio not found.' })
    const doc = snap.docs[0]
    const data = doc.data()
    // Public endpoint returns only fields used by the public portfolio renderer.
    const portfolio = {
      title: data.title || '', slug: data.slug || '', displayName: data.displayName || '',
      tagline: data.tagline || '', bio: data.bio || '', email: data.email || '',
      published: true, sections: Array.isArray(data.sections) ? data.sections.filter(s => s && s.visible !== false) : []
    }
    return res.json({ portfolio })
  } catch (err) { next(err) }
})
app.get('/api/me/portfolio', requireAuth, async (req, res, next) => {
  try {
    const snap = await db.collection('portfolios').doc(req.user.uid).get()
    return res.json({ portfolio: snap.exists ? snap.data() : null })
  } catch (err) { next(err) }
})
function sanitizePortfolio(body, uid, publishedOverride) {
  const safeSlug = String(body.slug || body.displayName || 'my-portfolio').toLowerCase().trim().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || `portfolio-${uid.slice(0, 8)}`
  const allowedTypes = new Set(['hero', 'about', 'skills', 'projects', 'experience', 'contact'])
  const sections = Array.isArray(body.sections) ? body.sections.slice(0, 20).filter(s => s && allowedTypes.has(s.type)).map(s => ({
    id: String(s.id || '').slice(0, 80),
    type: s.type,
    title: String(s.title || '').slice(0, 180),
    content: String(s.content || '').slice(0, 5000),
    visible: s.visible !== false
  })) : []
  return {
    uid, title: String(body.title || 'My Portfolio').slice(0, 120),
    slug: safeSlug, displayName: String(body.displayName || '').slice(0, 120),
    tagline: String(body.tagline || '').slice(0, 220), bio: String(body.bio || '').slice(0, 3000),
    email: String(body.email || '').slice(0, 254), sections,
    published: publishedOverride ?? body.published === true,
    updatedAt: new Date().toISOString()
  }
}
async function savePortfolio(req, res, publish) {
  const incoming = sanitizePortfolio(req.body || {}, req.user.uid, publish ? true : undefined)
  const existing = await db.collection('portfolios').doc(req.user.uid).get()
  // Prevent users from claiming a slug already assigned to another portfolio.
  const conflict = await db.collection('portfolios').where('slug', '==', incoming.slug).limit(2).get()
  if (conflict.docs.some(d => d.id !== req.user.uid)) return res.status(409).json({ error: 'That public URL is already in use. Choose another slug.' })
  if (existing.exists && existing.data().published === true && !publish) incoming.published = true
  incoming.createdAt = existing.exists ? (existing.data().createdAt || incoming.updatedAt) : incoming.updatedAt
  await db.collection('portfolios').doc(req.user.uid).set(incoming, { merge: true })
  return res.json({ ok: true, portfolio: incoming })
}
app.put('/api/me/portfolio', requireAuth, async (req, res, next) => {
  try { return await savePortfolio(req, res, false) } catch (err) { next(err) }
})
app.post('/api/me/publish', requireAuth, async (req, res, next) => {
  try { return await savePortfolio(req, res, true) } catch (err) { next(err) }
})
app.use((err, _req, res, _next) => {
  console.error(err)
  if (err.message === 'Origin not allowed by CORS') return res.status(403).json({ error: 'Origin not allowed.' })
  return res.status(500).json({ error: 'Unexpected server error.' })
})
const port = Number(process.env.PORT || 4000)
app.listen(port, () => console.log(`Portfolio API listening on ${port}`))